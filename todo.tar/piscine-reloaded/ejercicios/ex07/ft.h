#ifndef FT_H
# define FT_H

void    ft_putchar(char c);
void    ft_print_numbers(void);

#endif

